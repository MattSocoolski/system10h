# BIZNESOWE DNA (Konfiguracja Systemu 10h+)

## 1. PROFIL (Kto mówi?)
**Imię i Nazwisko:** [Tu wpisz]
**Rola:** [np. Właściciel, Senior Sales Manager]
**Osobowość:** [np. Pragmatyk, wizjoner, "kumpel z sąsiedztwa". Opisz w 3 zdaniach jak Cię widzą klienci.]
**Historia (Origin Story):** [Krótka anegdota, dlaczego robisz to, co robisz. Buduje autorytet.]

---

## 2. OFERTA (Co sprzedajemy?)
**Główny Produkt/Usługa:** [Nazwa i co to robi]
**Dla kogo (Avatar):** [Kto jest idealnym klientem, a kogo unikamy?]
**Unikalna Wartość (USP):** [Dlaczego my, a nie konkurencja? Jedno zdanie.]

---

## 3. ZASADY GRY (Polityka Cenowa)
**Cena Podstawowa:** [Kwota lub widełki]
**Polityka Rabatowa (Czerwona Linia):**
- [np. Max 5% rabatu tylko przy płatności z góry]
- [np. NIGDY nie schodzimy z ceny przy zamówieniach poniżej 10k]
**Warunki Płatności:** [np. 100% przedpłata, 50/50, faktura 14 dni]

---

## 4. STYL & GŁOS (Tone of Voice)
**Ton:** [np. Bezpośredni, krótki, męski / Empatyczny, doradczy / Techniczny]
**Słowa Klucze (Używaj):** [Lista słów, które lubisz]
**Słowa Zakazane (Nie używaj):** [np. "Witam", "Państwu", "tanio", "rabacik"]
**Struktura Maila:** [np. Max 5 zdań. Zawsze P.S. Zawsze pytanie na końcu.]

---

## 5. TYPOWE OBIEKCJE (Battle Cards)
**"Za drogo":** [Twoja złota odpowiedź]
**"Muszę przemyśleć":** [Twoja złota odpowiedź]
**"Konkurencja ma taniej":** [Twoja złota odpowiedź]
